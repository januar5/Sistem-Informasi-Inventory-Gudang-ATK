USE toko_steel;

-- 1. Seed Users (password: 'password')
INSERT INTO users (name, email, password, role) VALUES 
('Administrator', 'admin@atk.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Petugas Gudang', 'petugas@atk.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'petugas');

-- 2. Seed Categories (10)
INSERT INTO categories (nama_kategori) VALUES 
('Kertas'), ('Alat Tulis'), ('Peralatan Meja'), ('Buku & Jurnal'), ('Tinta & Toner'),
('Aksesoris Komputer'), ('Perlengkapan Presentasi'), ('Arsip & Map'), ('Peralatan Kebersihan'), ('Lain-lain');

-- 3. Seed Suppliers (10)
INSERT INTO suppliers (nama_supplier, alamat, no_hp) VALUES 
('PT Kertas Global', 'Jl. Merdeka No 1', '081234567890'),
('CV Tulis Jaya', 'Jl. Sudirman No 2', '081234567891'),
('Toko Meja Makmur', 'Jl. Thamrin No 3', '081234567892'),
('Pustaka Utama', 'Jl. Gatot Subroto 4', '081234567893'),
('Toner Sentosa', 'Jl. Rasuna Said 5', '081234567894'),
('Komp Access', 'Jl. Asia Afrika 6', '081234567895'),
('Presenta Solusi', 'Jl. Ahmad Yani 7', '081234567896'),
('Map Center', 'Jl. Diponegoro 8', '081234567897'),
('Bersih Cemerlang', 'Jl. Gajah Mada 9', '081234567898'),
('Mitra Usaha', 'Jl. Hayam Wuruk 10', '081234567899');

-- 4. Seed Items (10)
INSERT INTO items (kode_barang, nama_barang, category_id, supplier_id, stok, satuan) VALUES 
('ATK001', 'Kertas HVS A4 80gr', 1, 1, 100, 'Rim'),
('ATK002', 'Kertas HVS F4 70gr', 1, 1, 150, 'Rim'),
('ATK003', 'Kertas HVS A3 80gr', 1, 1, 50, 'Rim'),
('ATK004', 'Kertas Folio Bergaris', 1, 2, 200, 'Pack'),
('ATK005', 'Kertas Buram F4', 1, 2, 80, 'Rim'),
('ATK006', 'Pulpen Faster Hitam', 2, 2, 500, 'Pcs'),
('ATK007', 'Pulpen Faster Biru', 2, 2, 300, 'Pcs'),
('ATK008', 'Pulpen Pilot Merah', 2, 2, 100, 'Pcs'),
('ATK009', 'Pensil 2B Faber Castell', 2, 2, 400, 'Pcs'),
('ATK010', 'Spidol Boardmarker Hitam', 2, 3, 150, 'Pcs');
