<?php

class AuthMiddleware {
    public static function check() {
        if (!Session::get('user_id')) {
            Helper::setFlash('error', 'Silakan login terlebih dahulu.');
            Helper::redirect('/login');
        }
    }

    public static function isGuest() {
        if (Session::get('user_id')) {
            $role = Session::get('user_role');
            if ($role === 'admin') {
                Helper::redirect('/dashboard');
            } else {
                Helper::redirect('/dashboard');
            }
        }
    }
}
