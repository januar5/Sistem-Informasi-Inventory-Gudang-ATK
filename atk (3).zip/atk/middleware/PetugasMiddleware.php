<?php

class PetugasMiddleware {
    public static function check() {
        AuthMiddleware::check();
        
        if (Session::get('user_role') !== 'petugas') {
            // Admin is allowed everything, but if specific to petugas only:
            // if we want admin to also access petugas routes, we can allow both
            if(Session::get('user_role') !== 'admin') {
                Helper::setFlash('error', 'Akses ditolak.');
                Helper::redirect('/dashboard');
            }
        }
    }
}
