<?php

class AdminMiddleware {
    public static function check() {
        AuthMiddleware::check();
        
        if (Session::get('user_role') !== 'admin') {
            Helper::setFlash('error', 'Akses ditolak. Anda bukan Admin.');
            Helper::redirect('/dashboard');
        }
    }
}
