<?php

class ItemController {
    private $db;
    private $itemModel;
    private $categoryModel;
    private $supplierModel;

    public function __construct() {
        AdminMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/Item.php';
        require_once __DIR__ . '/../models/Category.php';
        require_once __DIR__ . '/../models/Supplier.php';
        
        $this->itemModel = new Item($this->db);
        $this->categoryModel = new Category($this->db);
        $this->supplierModel = new Supplier($this->db);
    }

    public function index() {
        $items = $this->itemModel->getAll();
        require_once __DIR__ . '/../views/items/index.php';
    }

    public function show($id) {
        $item = $this->itemModel->getById($id);
        if (!$item) {
            Helper::setFlash('error', 'Barang tidak ditemukan.');
            Helper::redirect('/item');
        }
        require_once __DIR__ . '/../views/items/show.php';
    }

    public function create() {
        $categories = $this->categoryModel->getAll();
        $suppliers = $this->supplierModel->getAll();
        $kode_barang = $this->itemModel->generateKodeBarang();
        require_once __DIR__ . '/../views/items/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $kode_barang = Validation::sanitizeInput($_POST['kode_barang']);
            $nama_barang = Validation::sanitizeInput($_POST['nama_barang']);
            $category_id = Validation::sanitizeInput($_POST['category_id']);
            $supplier_id = Validation::sanitizeInput($_POST['supplier_id']);
            $stok = Validation::sanitizeInput($_POST['stok']);
            $satuan = Validation::sanitizeInput($_POST['satuan']);

            if (empty($kode_barang) || empty($nama_barang) || empty($category_id) || empty($supplier_id) || $stok === '' || empty($satuan)) {
                Helper::setFlash('error', 'Semua field wajib diisi.');
                Helper::redirect('/item/create');
            }

            if ($this->itemModel->checkKodeExists($kode_barang)) {
                Helper::setFlash('error', 'Kode Barang sudah digunakan.');
                Helper::redirect('/item/create');
            }

            $this->itemModel->kode_barang = $kode_barang;
            $this->itemModel->nama_barang = $nama_barang;
            $this->itemModel->category_id = $category_id;
            $this->itemModel->supplier_id = $supplier_id;
            $this->itemModel->stok = $stok;
            $this->itemModel->satuan = $satuan;

            if ($this->itemModel->create()) {
                Helper::setFlash('success', 'Barang berhasil ditambahkan.');
                Helper::redirect('/item');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan barang.');
                Helper::redirect('/item/create');
            }
        }
    }

    public function edit($id) {
        $item = $this->itemModel->getById($id);
        if (!$item) {
            Helper::setFlash('error', 'Barang tidak ditemukan.');
            Helper::redirect('/item');
        }
        $categories = $this->categoryModel->getAll();
        $suppliers = $this->supplierModel->getAll();
        require_once __DIR__ . '/../views/items/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $nama_barang = Validation::sanitizeInput($_POST['nama_barang']);
            $category_id = Validation::sanitizeInput($_POST['category_id']);
            $supplier_id = Validation::sanitizeInput($_POST['supplier_id']);
            $satuan = Validation::sanitizeInput($_POST['satuan']);

            if (empty($nama_barang) || empty($category_id) || empty($supplier_id) || empty($satuan)) {
                Helper::setFlash('error', 'Semua field wajib diisi kecuali stok.');
                Helper::redirect('/item/edit/' . $id);
            }

            $this->itemModel->id = $id;
            $this->itemModel->nama_barang = $nama_barang;
            $this->itemModel->category_id = $category_id;
            $this->itemModel->supplier_id = $supplier_id;
            $this->itemModel->satuan = $satuan;
            // Note: Stok tidak diupdate dari sini, melainkan dari barang masuk/keluar

            if ($this->itemModel->update()) {
                Helper::setFlash('success', 'Barang berhasil diperbarui.');
                Helper::redirect('/item');
            } else {
                Helper::setFlash('error', 'Gagal memperbarui barang.');
                Helper::redirect('/item/edit/' . $id);
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            $this->itemModel->id = $id;
            if ($this->itemModel->delete()) {
                Helper::setFlash('success', 'Barang berhasil dihapus.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus barang. Barang mungkin memiliki transaksi.');
            }
            Helper::redirect('/item');
        }
    }
}
