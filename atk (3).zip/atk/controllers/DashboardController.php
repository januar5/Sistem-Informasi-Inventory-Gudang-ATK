<?php

class DashboardController {
    private $db;

    public function __construct() {
        AuthMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index() {
        require_once __DIR__ . '/../models/Item.php';
        require_once __DIR__ . '/../models/Category.php';
        require_once __DIR__ . '/../models/Supplier.php';
        require_once __DIR__ . '/../models/IncomingItem.php';
        require_once __DIR__ . '/../models/OutgoingItem.php';

        $itemModel = new Item($this->db);
        $categoryModel = new Category($this->db);
        $supplierModel = new Supplier($this->db);
        $incomingModel = new IncomingItem($this->db);
        $outgoingModel = new OutgoingItem($this->db);

        $data = [
            'total_barang' => $itemModel->getTotal(),
            'total_kategori' => $categoryModel->getTotal(),
            'total_supplier' => $supplierModel->getTotal(),
            'total_masuk' => $incomingModel->getTotal(),
            'total_keluar' => $outgoingModel->getTotal(),
            'total_stok' => $itemModel->getTotalStok(),
            'low_stock' => $itemModel->getLowStock(),
            'warning_stock' => $itemModel->getWarningStock(),
            'available_stock' => $itemModel->getAvailableStock(),
            'chart_incoming' => array_reverse($incomingModel->getMonthlyStats()),
            'chart_outgoing' => array_reverse($outgoingModel->getMonthlyStats()),
            'all_items' => $itemModel->getAll()
        ];

        $role = Session::get('user_role');
        if ($role === 'admin') {
            require_once __DIR__ . '/../views/dashboard/admin.php';
        } else {
            require_once __DIR__ . '/../views/dashboard/petugas.php';
        }
    }
}
