<?php

class SupplierController {
    private $db;
    private $supplierModel;

    public function __construct() {
        AdminMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/Supplier.php';
        $this->supplierModel = new Supplier($this->db);
    }

    public function index() {
        $suppliers = $this->supplierModel->getAll();
        require_once __DIR__ . '/../views/suppliers/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/suppliers/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $nama_supplier = Validation::sanitizeInput($_POST['nama_supplier']);
            $alamat = Validation::sanitizeInput($_POST['alamat']);
            $no_hp = Validation::sanitizeInput($_POST['no_hp']);

            if (empty($nama_supplier)) {
                Helper::setFlash('error', 'Nama Supplier wajib diisi.');
                Helper::redirect('/supplier/create');
            }

            $this->supplierModel->nama_supplier = $nama_supplier;
            $this->supplierModel->alamat = $alamat;
            $this->supplierModel->no_hp = $no_hp;

            if ($this->supplierModel->create()) {
                Helper::setFlash('success', 'Supplier berhasil ditambahkan.');
                Helper::redirect('/supplier');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan supplier.');
                Helper::redirect('/supplier/create');
            }
        }
    }

    public function edit($id) {
        $supplier = $this->supplierModel->getById($id);
        if (!$supplier) {
            Helper::setFlash('error', 'Supplier tidak ditemukan.');
            Helper::redirect('/supplier');
        }
        require_once __DIR__ . '/../views/suppliers/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $nama_supplier = Validation::sanitizeInput($_POST['nama_supplier']);
            $alamat = Validation::sanitizeInput($_POST['alamat']);
            $no_hp = Validation::sanitizeInput($_POST['no_hp']);

            if (empty($nama_supplier)) {
                Helper::setFlash('error', 'Nama Supplier wajib diisi.');
                Helper::redirect('/supplier/edit/' . $id);
            }

            $this->supplierModel->id = $id;
            $this->supplierModel->nama_supplier = $nama_supplier;
            $this->supplierModel->alamat = $alamat;
            $this->supplierModel->no_hp = $no_hp;

            if ($this->supplierModel->update()) {
                Helper::setFlash('success', 'Supplier berhasil diperbarui.');
                Helper::redirect('/supplier');
            } else {
                Helper::setFlash('error', 'Gagal memperbarui supplier.');
                Helper::redirect('/supplier/edit/' . $id);
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            $this->supplierModel->id = $id;
            if ($this->supplierModel->delete()) {
                Helper::setFlash('success', 'Supplier berhasil dihapus.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus supplier. Supplier mungkin sedang digunakan oleh barang.');
            }
            Helper::redirect('/supplier');
        }
    }
}
