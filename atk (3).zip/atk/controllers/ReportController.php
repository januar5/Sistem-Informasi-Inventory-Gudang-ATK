<?php

class ReportController {
    private $db;

    public function __construct() {
        AuthMiddleware::check(); // Both admin and petugas can access
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index() {
        require_once __DIR__ . '/../views/reports/index.php';
    }

    public function print_barang() {
        require_once __DIR__ . '/../models/Item.php';
        $itemModel = new Item($this->db);
        $items = $itemModel->getAll();

        if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
            $this->generatePdf('reports/barang_pdf.php', ['items' => $items], 'Laporan_Barang.pdf', 'landscape');
        } elseif (isset($_GET['export']) && $_GET['export'] == 'excel') {
            $this->generateExcel('reports/barang_pdf.php', ['items' => $items], 'Laporan_Barang.xls');
        } else {
            require_once __DIR__ . '/../reports/barang_pdf.php';
        }
    }

    public function print_masuk() {
        require_once __DIR__ . '/../models/IncomingItem.php';
        $incomingModel = new IncomingItem($this->db);
        
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

        // Simplification for the test: Using getAll and filtering in PHP if needed, 
        // or modifying query in a real app. We'll modify query here for better approach
        $query = "SELECT inc.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM incoming_items inc 
                  LEFT JOIN items i ON inc.item_id = i.id WHERE 1=1";
        
        if (!empty($start_date)) {
            $query .= " AND inc.tanggal >= :start_date";
        }
        if (!empty($end_date)) {
            $query .= " AND inc.tanggal <= :end_date";
        }
        
        $query .= " ORDER BY inc.tanggal ASC";
        
        $stmt = $this->db->prepare($query);
        if (!empty($start_date)) $stmt->bindParam(':start_date', $start_date);
        if (!empty($end_date)) $stmt->bindParam(':end_date', $end_date);
        $stmt->execute();
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $data = [
            'items' => $items,
            'start_date' => $start_date,
            'end_date' => $end_date
        ];

        if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
            $this->generatePdf('reports/barang_masuk_pdf.php', $data, 'Laporan_Barang_Masuk.pdf');
        } elseif (isset($_GET['export']) && $_GET['export'] == 'excel') {
            $this->generateExcel('reports/barang_masuk_pdf.php', $data, 'Laporan_Barang_Masuk.xls');
        } else {
            extract($data);
            require_once __DIR__ . '/../reports/barang_masuk_pdf.php';
        }
    }

    public function print_keluar() {
        require_once __DIR__ . '/../models/OutgoingItem.php';
        $outgoingModel = new OutgoingItem($this->db);
        
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

        $query = "SELECT outg.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM outgoing_items outg 
                  LEFT JOIN items i ON outg.item_id = i.id WHERE 1=1";
        
        if (!empty($start_date)) {
            $query .= " AND outg.tanggal >= :start_date";
        }
        if (!empty($end_date)) {
            $query .= " AND outg.tanggal <= :end_date";
        }
        
        $query .= " ORDER BY outg.tanggal ASC";
        
        $stmt = $this->db->prepare($query);
        if (!empty($start_date)) $stmt->bindParam(':start_date', $start_date);
        if (!empty($end_date)) $stmt->bindParam(':end_date', $end_date);
        $stmt->execute();
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $data = [
            'items' => $items,
            'start_date' => $start_date,
            'end_date' => $end_date
        ];

        if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
            $this->generatePdf('reports/barang_keluar_pdf.php', $data, 'Laporan_Barang_Keluar.pdf');
        } elseif (isset($_GET['export']) && $_GET['export'] == 'excel') {
            $this->generateExcel('reports/barang_keluar_pdf.php', $data, 'Laporan_Barang_Keluar.xls');
        } else {
            extract($data);
            require_once __DIR__ . '/../reports/barang_keluar_pdf.php';
        }
    }

    public function print_stok() {
        require_once __DIR__ . '/../models/Item.php';
        $itemModel = new Item($this->db);
        $items = $itemModel->getAll();

        if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
            $this->generatePdf('reports/stok_pdf.php', ['items' => $items], 'Laporan_Stok_Barang.pdf');
        } elseif (isset($_GET['export']) && $_GET['export'] == 'excel') {
            $this->generateExcel('reports/stok_pdf.php', ['items' => $items], 'Laporan_Stok_Barang.xls');
        } else {
            require_once __DIR__ . '/../reports/stok_pdf.php';
        }
    }

    private function generatePdf($viewPath, $data, $filename, $paper = 'portrait') {
        if (!file_exists(__DIR__ . '/../vendor/autoload.php')) {
            die("Composer autoload not found. Please run 'composer install' to use DomPDF.");
        }
        
        require_once __DIR__ . '/../vendor/autoload.php';
        
        $options = new \Dompdf\Options();
        $options->set('isRemoteEnabled', true);
        $options->set('isHtml5ParserEnabled', true);
        
        $dompdf = new \Dompdf\Dompdf($options);
        
        ob_start();
        extract($data);
        require_once __DIR__ . '/../' . $viewPath;
        $html = ob_get_clean();
        
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', $paper);
        $dompdf->render();
        $dompdf->stream($filename, ["Attachment" => true]);
        exit;
    }

    private function generateExcel($viewPath, $data, $filename) {
        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Pragma: no-cache");
        header("Expires: 0");
        
        extract($data);
        require_once __DIR__ . '/../' . $viewPath;
        exit;
    }
}
