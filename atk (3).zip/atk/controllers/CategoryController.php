<?php

class CategoryController {
    private $db;
    private $categoryModel;

    public function __construct() {
        AdminMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/Category.php';
        $this->categoryModel = new Category($this->db);
    }

    public function index() {
        $categories = $this->categoryModel->getAll();
        require_once __DIR__ . '/../views/categories/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/categories/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $nama_kategori = Validation::sanitizeInput($_POST['nama_kategori']);

            if (empty($nama_kategori)) {
                Helper::setFlash('error', 'Nama Kategori wajib diisi.');
                Helper::redirect('/category/create');
            }

            $this->categoryModel->nama_kategori = $nama_kategori;

            if ($this->categoryModel->create()) {
                Helper::setFlash('success', 'Kategori berhasil ditambahkan.');
                Helper::redirect('/category');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan kategori.');
                Helper::redirect('/category/create');
            }
        }
    }

    public function edit($id) {
        $category = $this->categoryModel->getById($id);
        if (!$category) {
            Helper::setFlash('error', 'Kategori tidak ditemukan.');
            Helper::redirect('/category');
        }
        require_once __DIR__ . '/../views/categories/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $nama_kategori = Validation::sanitizeInput($_POST['nama_kategori']);

            if (empty($nama_kategori)) {
                Helper::setFlash('error', 'Nama Kategori wajib diisi.');
                Helper::redirect('/category/edit/' . $id);
            }

            $this->categoryModel->id = $id;
            $this->categoryModel->nama_kategori = $nama_kategori;

            if ($this->categoryModel->update()) {
                Helper::setFlash('success', 'Kategori berhasil diperbarui.');
                Helper::redirect('/category');
            } else {
                Helper::setFlash('error', 'Gagal memperbarui kategori.');
                Helper::redirect('/category/edit/' . $id);
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            $this->categoryModel->id = $id;
            if ($this->categoryModel->delete()) {
                Helper::setFlash('success', 'Kategori berhasil dihapus.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus kategori. Kategori mungkin sedang digunakan oleh barang.');
            }
            Helper::redirect('/category');
        }
    }
}
