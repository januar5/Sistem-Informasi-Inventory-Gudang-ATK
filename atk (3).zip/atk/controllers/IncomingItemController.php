<?php

class IncomingItemController {
    private $db;
    private $incomingModel;
    private $itemModel;

    public function __construct() {
        AuthMiddleware::check(); // Both admin and petugas can access
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/IncomingItem.php';
        require_once __DIR__ . '/../models/Item.php';
        
        $this->incomingModel = new IncomingItem($this->db);
        $this->itemModel = new Item($this->db);
    }

    public function index() {
        $incoming_items = $this->incomingModel->getAll();
        require_once __DIR__ . '/../views/incoming_items/index.php';
    }

    public function create() {
        $items = $this->itemModel->getAll();
        require_once __DIR__ . '/../views/incoming_items/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $item_id = Validation::sanitizeInput($_POST['item_id']);
            $tanggal = Validation::sanitizeInput($_POST['tanggal']);
            $jumlah = Validation::sanitizeInput($_POST['jumlah']);
            $keterangan = Validation::sanitizeInput($_POST['keterangan']);

            if (empty($item_id) || empty($tanggal) || empty($jumlah) || $jumlah <= 0) {
                Helper::setFlash('error', 'Field Barang, Tanggal, dan Jumlah (minimal 1) wajib diisi.');
                Helper::redirect('/incoming/create');
            }

            $this->incomingModel->item_id = $item_id;
            $this->incomingModel->tanggal = $tanggal;
            $this->incomingModel->jumlah = $jumlah;
            $this->incomingModel->keterangan = $keterangan;

            if ($this->incomingModel->create()) {
                Helper::setFlash('success', 'Transaksi Barang Masuk berhasil ditambahkan dan stok telah bertambah.');
                Helper::redirect('/incoming');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan transaksi.');
                Helper::redirect('/incoming/create');
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            $incoming = $this->incomingModel->getById($id);
            if (!$incoming) {
                Helper::setFlash('error', 'Transaksi tidak ditemukan.');
                Helper::redirect('/incoming');
            }

            $this->incomingModel->id = $id;
            if ($this->incomingModel->delete($incoming['item_id'], $incoming['jumlah'])) {
                Helper::setFlash('success', 'Transaksi berhasil dihapus dan stok telah disesuaikan.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus transaksi. Stok tidak mencukupi untuk dihapus (akan menjadi negatif).');
            }
            Helper::redirect('/incoming');
        }
    }

    public function edit($id) {
        $incoming = $this->incomingModel->getById($id);
        if (!$incoming) {
            Helper::setFlash('error', 'Transaksi tidak ditemukan.');
            Helper::redirect('/incoming');
        }
        $items = $this->itemModel->getAll();
        require_once __DIR__ . '/../views/incoming_items/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $incoming = $this->incomingModel->getById($id);
            if (!$incoming) {
                Helper::setFlash('error', 'Transaksi tidak ditemukan.');
                Helper::redirect('/incoming');
            }

            $tanggal = Validation::sanitizeInput($_POST['tanggal']);
            $jumlah = Validation::sanitizeInput($_POST['jumlah']);
            $keterangan = Validation::sanitizeInput($_POST['keterangan']);

            if (empty($tanggal) || empty($jumlah) || $jumlah <= 0) {
                Helper::setFlash('error', 'Tanggal dan Jumlah (minimal 1) wajib diisi.');
                Helper::redirect("/incoming/edit/$id");
            }

            $old_jumlah = $incoming['jumlah'];
            $this->incomingModel->id = $id;
            $this->incomingModel->item_id = $incoming['item_id']; // Item ID remains unchanged
            $this->incomingModel->tanggal = $tanggal;
            $this->incomingModel->jumlah = $jumlah;
            $this->incomingModel->keterangan = $keterangan;

            if ($this->incomingModel->update($old_jumlah)) {
                Helper::setFlash('success', 'Transaksi Barang Masuk berhasil diupdate.');
                Helper::redirect('/incoming');
            } else {
                Helper::setFlash('error', 'Gagal mengupdate transaksi.');
                Helper::redirect("/incoming/edit/$id");
            }
        }
    }
}
