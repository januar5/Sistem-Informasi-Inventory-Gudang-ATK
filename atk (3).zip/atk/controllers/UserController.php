<?php

class UserController {
    private $db;
    private $userModel;

    public function __construct() {
        AdminMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/User.php';
        $this->userModel = new User($this->db);
    }

    public function index() {
        $users = $this->userModel->getAllUsers();
        require_once __DIR__ . '/../views/users/index.php';
    }

    public function create() {
        require_once __DIR__ . '/../views/users/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $name = Validation::sanitizeInput($_POST['name']);
            $email = Validation::sanitizeInput($_POST['email']);
            $password = $_POST['password'];
            $role = Validation::sanitizeInput($_POST['role']);

            $_SESSION['old'] = $_POST;

            if (empty($name) || empty($email) || empty($password) || empty($role)) {
                Helper::setFlash('error', 'Semua field wajib diisi.');
                Helper::redirect('/user/create');
            }

            if ($this->userModel->isEmailExists($email)) {
                Helper::setFlash('error', 'Email sudah terdaftar.');
                Helper::redirect('/user/create');
            }

            $this->userModel->name = $name;
            $this->userModel->email = $email;
            $this->userModel->password = password_hash($password, PASSWORD_DEFAULT);
            $this->userModel->role = $role;

            if ($this->userModel->create()) {
                Helper::clearOld();
                Helper::setFlash('success', 'User berhasil ditambahkan.');
                Helper::redirect('/user');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan user.');
                Helper::redirect('/user/create');
            }
        }
    }

    public function edit($id) {
        $user = $this->userModel->getUserById($id);
        if (!$user) {
            Helper::setFlash('error', 'User tidak ditemukan.');
            Helper::redirect('/user');
        }
        require_once __DIR__ . '/../views/users/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $name = Validation::sanitizeInput($_POST['name']);
            $email = Validation::sanitizeInput($_POST['email']);
            $role = Validation::sanitizeInput($_POST['role']);
            $password = $_POST['password'];

            if (empty($name) || empty($email) || empty($role)) {
                Helper::setFlash('error', 'Nama, Email dan Role wajib diisi.');
                Helper::redirect('/user/edit/' . $id);
            }

            if ($this->userModel->isEmailExists($email, $id)) {
                Helper::setFlash('error', 'Email sudah digunakan.');
                Helper::redirect('/user/edit/' . $id);
            }

            $this->userModel->id = $id;
            $this->userModel->name = $name;
            $this->userModel->email = $email;
            $this->userModel->role = $role;

            if ($this->userModel->update()) {
                if (!empty($password)) {
                    $this->userModel->password = password_hash($password, PASSWORD_DEFAULT);
                    $this->userModel->updatePassword();
                }
                Helper::setFlash('success', 'User berhasil diperbarui.');
                Helper::redirect('/user');
            } else {
                Helper::setFlash('error', 'Gagal memperbarui user.');
                Helper::redirect('/user/edit/' . $id);
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            if ($id == Session::get('user_id')) {
                Helper::setFlash('error', 'Anda tidak dapat menghapus akun Anda sendiri.');
                Helper::redirect('/user');
            }

            $this->userModel->id = $id;
            if ($this->userModel->delete()) {
                Helper::setFlash('success', 'User berhasil dihapus.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus user.');
            }
            Helper::redirect('/user');
        }
    }
}
