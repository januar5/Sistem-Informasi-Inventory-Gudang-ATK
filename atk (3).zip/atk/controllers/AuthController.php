<?php

class AuthController {
    private $db;
    private $userModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/User.php';
        $this->userModel = new User($this->db);
    }

    public function login() {
        AuthMiddleware::isGuest();
        require_once __DIR__ . '/../views/auth/login.php';
    }

    public function processLogin() {
        AuthMiddleware::isGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $email = Validation::sanitizeInput($_POST['email']);
            $password = $_POST['password'];

            if (empty($email) || empty($password)) {
                Helper::setFlash('error', 'Email dan password harus diisi.');
                Helper::redirect('/login');
            }

            $user = $this->userModel->login($email);

            if ($user && password_verify($password, $user['password'])) {
                Session::regenerate();
                Session::set('user_id', $user['id']);
                Session::set('user_name', $user['name']);
                Session::set('user_email', $user['email']);
                Session::set('user_role', $user['role']);

                Helper::setFlash('success', 'Selamat datang, ' . $user['name'] . '!');
                Helper::redirect('/dashboard');
            } else {
                Helper::setFlash('error', 'Email atau password salah.');
                Helper::redirect('/login');
            }
        }
    }

    public function logout() {
        Session::destroy();
        Helper::redirect('/login');
    }
}
