<?php

class OutgoingItemController {
    private $db;
    private $outgoingModel;
    private $itemModel;

    public function __construct() {
        AuthMiddleware::check(); // Both admin and petugas can access
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/OutgoingItem.php';
        require_once __DIR__ . '/../models/Item.php';
        
        $this->outgoingModel = new OutgoingItem($this->db);
        $this->itemModel = new Item($this->db);
    }

    public function index() {
        $outgoing_items = $this->outgoingModel->getAll();
        require_once __DIR__ . '/../views/outgoing_items/index.php';
    }

    public function create() {
        $items = $this->itemModel->getAll();
        require_once __DIR__ . '/../views/outgoing_items/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $item_id = Validation::sanitizeInput($_POST['item_id']);
            $tanggal = Validation::sanitizeInput($_POST['tanggal']);
            $jumlah = Validation::sanitizeInput($_POST['jumlah']);
            $keterangan = Validation::sanitizeInput($_POST['keterangan']);

            if (empty($item_id) || empty($tanggal) || empty($jumlah) || $jumlah <= 0) {
                Helper::setFlash('error', 'Field Barang, Tanggal, dan Jumlah (minimal 1) wajib diisi.');
                Helper::redirect('/outgoing/create');
            }

            $this->outgoingModel->item_id = $item_id;
            $this->outgoingModel->tanggal = $tanggal;
            $this->outgoingModel->jumlah = $jumlah;
            $this->outgoingModel->keterangan = $keterangan;

            $result = $this->outgoingModel->create();
            
            if ($result === true) {
                Helper::setFlash('success', 'Transaksi Barang Keluar berhasil ditambahkan dan stok telah berkurang.');
                Helper::redirect('/outgoing');
            } elseif ($result === 'insufficient_stock') {
                Helper::setFlash('error', 'Stok tidak mencukupi untuk transaksi ini.');
                Helper::redirect('/outgoing/create');
            } else {
                Helper::setFlash('error', 'Gagal menambahkan transaksi.');
                Helper::redirect('/outgoing/create');
            }
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }
            
            $outgoing = $this->outgoingModel->getById($id);
            if (!$outgoing) {
                Helper::setFlash('error', 'Transaksi tidak ditemukan.');
                Helper::redirect('/outgoing');
            }

            $this->outgoingModel->id = $id;
            if ($this->outgoingModel->delete($outgoing['item_id'], $outgoing['jumlah'])) {
                Helper::setFlash('success', 'Transaksi berhasil dihapus dan stok telah disesuaikan.');
            } else {
                Helper::setFlash('error', 'Gagal menghapus transaksi.');
            }
            Helper::redirect('/outgoing');
        }
    }

    public function edit($id) {
        $outgoing = $this->outgoingModel->getById($id);
        if (!$outgoing) {
            Helper::setFlash('error', 'Transaksi tidak ditemukan.');
            Helper::redirect('/outgoing');
        }
        $items = $this->itemModel->getAll();
        require_once __DIR__ . '/../views/outgoing_items/edit.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $outgoing = $this->outgoingModel->getById($id);
            if (!$outgoing) {
                Helper::setFlash('error', 'Transaksi tidak ditemukan.');
                Helper::redirect('/outgoing');
            }

            $tanggal = Validation::sanitizeInput($_POST['tanggal']);
            $jumlah = Validation::sanitizeInput($_POST['jumlah']);
            $keterangan = Validation::sanitizeInput($_POST['keterangan']);

            if (empty($tanggal) || empty($jumlah) || $jumlah <= 0) {
                Helper::setFlash('error', 'Tanggal dan Jumlah (minimal 1) wajib diisi.');
                Helper::redirect("/outgoing/edit/$id");
            }

            $old_jumlah = $outgoing['jumlah'];
            $this->outgoingModel->id = $id;
            $this->outgoingModel->item_id = $outgoing['item_id']; // Item ID remains unchanged
            $this->outgoingModel->tanggal = $tanggal;
            $this->outgoingModel->jumlah = $jumlah;
            $this->outgoingModel->keterangan = $keterangan;

            $result = $this->outgoingModel->update($old_jumlah);
            
            if ($result === true) {
                Helper::setFlash('success', 'Transaksi Barang Keluar berhasil diupdate.');
                Helper::redirect('/outgoing');
            } elseif ($result === 'insufficient_stock') {
                Helper::setFlash('error', 'Gagal mengupdate: Stok barang tidak mencukupi untuk penambahan pengeluaran ini.');
                Helper::redirect("/outgoing/edit/$id");
            } else {
                Helper::setFlash('error', 'Gagal mengupdate transaksi.');
                Helper::redirect("/outgoing/edit/$id");
            }
        }
    }
}
