<?php

class ProfileController {
    private $db;
    private $userModel;

    public function __construct() {
        AuthMiddleware::check();
        $database = new Database();
        $this->db = $database->getConnection();
        require_once __DIR__ . '/../models/User.php';
        $this->userModel = new User($this->db);
    }

    public function index() {
        $id = Session::get('user_id');
        $user = $this->userModel->getUserById($id);
        require_once __DIR__ . '/../views/profile/index.php';
    }

    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $id = Session::get('user_id');
            $name = Validation::sanitizeInput($_POST['name']);
            $email = Validation::sanitizeInput($_POST['email']);
            
            if (empty($name) || empty($email)) {
                Helper::setFlash('error', 'Nama dan Email wajib diisi.');
                Helper::redirect('/profile');
            }

            if ($this->userModel->isEmailExists($email, $id)) {
                Helper::setFlash('error', 'Email sudah digunakan oleh user lain.');
                Helper::redirect('/profile');
            }

            $this->userModel->id = $id;
            $this->userModel->name = $name;
            $this->userModel->email = $email;
            $this->userModel->role = Session::get('user_role');

            if ($this->userModel->update()) {
                Session::set('user_name', $name);
                Session::set('user_email', $email);
                Helper::setFlash('success', 'Profile berhasil diperbarui.');
            } else {
                Helper::setFlash('error', 'Gagal memperbarui profile.');
            }
            Helper::redirect('/profile');
        }
    }

    public function password() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Csrf::verifyToken($_POST['csrf_token'])) {
                die("CSRF Token Invalid");
            }

            $id = Session::get('user_id');
            $old_password = $_POST['old_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
                Helper::setFlash('error', 'Semua field password wajib diisi.');
                Helper::redirect('/profile');
            }

            if ($new_password !== $confirm_password) {
                Helper::setFlash('error', 'Password baru dan konfirmasi tidak cocok.');
                Helper::redirect('/profile');
            }

            $currentUser = $this->userModel->login(Session::get('user_email'));

            if (!password_verify($old_password, $currentUser['password'])) {
                Helper::setFlash('error', 'Password lama salah.');
                Helper::redirect('/profile');
            }

            $this->userModel->id = $id;
            $this->userModel->password = password_hash($new_password, PASSWORD_DEFAULT);

            if ($this->userModel->updatePassword()) {
                Helper::setFlash('success', 'Password berhasil diubah.');
            } else {
                Helper::setFlash('error', 'Gagal mengubah password.');
            }
            Helper::redirect('/profile');
        }
    }
}
