<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Barang</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
        .title { font-size: 18px; font-weight: bold; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #555; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        .text-center { text-align: center; }
        .footer { margin-top: 30px; font-size: 10px; text-align: right; font-style: italic; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN DATA BARANG</div>
        <div class="subtitle">Sistem Informasi Inventory Gudang ATK</div>
        <div>Tanggal Cetak: <?= date('d/m/Y H:i') ?></div>
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%" class="text-center">No</th>
                <th width="15%">Kode Barang</th>
                <th width="30%">Nama Barang</th>
                <th width="20%">Kategori</th>
                <th width="20%">Supplier</th>
                <th width="10%" class="text-center">Satuan</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; foreach($items as $item): ?>
            <tr>
                <td class="text-center"><?= $no++ ?></td>
                <td><?= $item['kode_barang'] ?></td>
                <td><?= $item['nama_barang'] ?></td>
                <td><?= $item['nama_kategori'] ?></td>
                <td><?= $item['nama_supplier'] ?></td>
                <td class="text-center"><?= $item['satuan'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="footer">
        Dicetak oleh: <?= Session::get('user_name') ?> (<?= ucfirst(Session::get('user_role')) ?>)
    </div>
    
    <?php if(!isset($_GET['export'])): ?>
    <script>window.print();</script>
    <?php endif; ?>
</body>
</html>
