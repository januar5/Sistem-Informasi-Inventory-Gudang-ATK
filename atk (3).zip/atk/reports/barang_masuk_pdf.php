<!DOCTYPE html>
<html>
<head>
    <title>Laporan Barang Masuk</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
        .title { font-size: 18px; font-weight: bold; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #555; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .footer { margin-top: 30px; font-size: 10px; text-align: right; font-style: italic; }
        .filter-info { margin-bottom: 10px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN BARANG MASUK</div>
        <div class="subtitle">Sistem Informasi Inventory Gudang ATK</div>
        <div>Tanggal Cetak: <?= date('d/m/Y H:i') ?></div>
    </div>

    <?php if(!empty($start_date) || !empty($end_date)): ?>
    <div class="filter-info">
        Periode: <?= !empty($start_date) ? date('d/m/Y', strtotime($start_date)) : 'Awal' ?> 
        s/d <?= !empty($end_date) ? date('d/m/Y', strtotime($end_date)) : 'Akhir' ?>
    </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th width="5%" class="text-center">No</th>
                <th width="15%">Tanggal</th>
                <th width="15%">Kode Barang</th>
                <th width="25%">Nama Barang</th>
                <th width="10%" class="text-center">Jumlah</th>
                <th width="30%">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no=1; 
            $total_masuk = 0;
            foreach($items as $item): 
                $total_masuk += $item['jumlah'];
            ?>
            <tr>
                <td class="text-center"><?= $no++ ?></td>
                <td><?= date('d/m/Y', strtotime($item['tanggal'])) ?></td>
                <td><?= $item['kode_barang'] ?></td>
                <td><?= $item['nama_barang'] ?></td>
                <td class="text-center"><?= $item['jumlah'] ?> <?= $item['satuan'] ?></td>
                <td><?= $item['keterangan'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="4" class="text-right">Total Keseluruhan:</th>
                <th class="text-center"><?= $total_masuk ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>

    <div class="footer">
        Dicetak oleh: <?= Session::get('user_name') ?> (<?= ucfirst(Session::get('user_role')) ?>)
    </div>
    
    <?php if(!isset($_GET['export'])): ?>
    <script>window.print();</script>
    <?php endif; ?>
</body>
</html>
