/**
 * Custom JavaScript for ATK Inventory System
 */

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds if not handled by SweetAlert
    const alerts = document.querySelectorAll('.alert:not(.swal2-popup)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

    // Simple script to format numbers to IDR format in inputs if needed
    const formatNumberInputs = document.querySelectorAll('.format-number');
    formatNumberInputs.forEach(function(input) {
        input.addEventListener('keyup', function(e) {
            let val = this.value.replace(/[^0-9]/g, '');
            if(val) {
                this.value = parseInt(val).toLocaleString('id-ID');
            }
        });
    });
});
