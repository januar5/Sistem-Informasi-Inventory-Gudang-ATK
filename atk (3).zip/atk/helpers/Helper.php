<?php

class Helper {
    public static function redirect($url) {
        header("Location: " . BASE_URL . $url);
        exit();
    }

    public static function formatRupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }

    public static function formatDate($date) {
        return date('d/m/Y', strtotime($date));
    }

    public static function setFlash($type, $message) {
        $_SESSION['flash'] = [
            'type' => $type,
            'message' => $message
        ];
    }

    public static function getFlash() {
        if (isset($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];
            unset($_SESSION['flash']);
            return $flash;
        }
        return null;
    }

    public static function old($key, $default = '') {
        return isset($_SESSION['old'][$key]) ? $_SESSION['old'][$key] : $default;
    }
    
    public static function clearOld() {
        if(isset($_SESSION['old'])) {
            unset($_SESSION['old']);
        }
    }
}
