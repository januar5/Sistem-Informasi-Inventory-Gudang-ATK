<?php

class IncomingItem {
    private $conn;
    private $table_name = "incoming_items";

    public $id;
    public $item_id;
    public $tanggal;
    public $jumlah;
    public $keterangan;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT inc.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM " . $this->table_name . " inc 
                  LEFT JOIN items i ON inc.item_id = i.id 
                  ORDER BY inc.tanggal DESC, inc.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT inc.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM " . $this->table_name . " inc 
                  LEFT JOIN items i ON inc.item_id = i.id 
                  WHERE inc.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create() {
        try {
            $this->conn->beginTransaction();

            $query = "INSERT INTO " . $this->table_name . " 
                      (item_id, tanggal, jumlah, keterangan) 
                      VALUES (:item_id, :tanggal, :jumlah, :keterangan)";
            $stmt = $this->conn->prepare($query);

            $this->item_id = htmlspecialchars(strip_tags($this->item_id));
            $this->tanggal = htmlspecialchars(strip_tags($this->tanggal));
            $this->jumlah = htmlspecialchars(strip_tags($this->jumlah));
            $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));

            $stmt->bindParam(':item_id', $this->item_id);
            $stmt->bindParam(':tanggal', $this->tanggal);
            $stmt->bindParam(':jumlah', $this->jumlah);
            $stmt->bindParam(':keterangan', $this->keterangan);

            $stmt->execute();

            // Update Stok
            $queryStok = "UPDATE items SET stok = stok + :jumlah WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':jumlah', $this->jumlah);
            $stmtStok->bindParam(':item_id', $this->item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function update($old_jumlah) {
        try {
            $this->conn->beginTransaction();

            $query = "UPDATE " . $this->table_name . " 
                      SET item_id = :item_id, tanggal = :tanggal, 
                          jumlah = :jumlah, keterangan = :keterangan 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);

            $this->item_id = htmlspecialchars(strip_tags($this->item_id));
            $this->tanggal = htmlspecialchars(strip_tags($this->tanggal));
            $this->jumlah = htmlspecialchars(strip_tags($this->jumlah));
            $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));
            $this->id = htmlspecialchars(strip_tags($this->id));

            $stmt->bindParam(':item_id', $this->item_id);
            $stmt->bindParam(':tanggal', $this->tanggal);
            $stmt->bindParam(':jumlah', $this->jumlah);
            $stmt->bindParam(':keterangan', $this->keterangan);
            $stmt->bindParam(':id', $this->id);

            $stmt->execute();

            // Update Stok: Restore old stock then subtract/add new stock
            $diff = $this->jumlah - $old_jumlah;
            $queryStok = "UPDATE items SET stok = stok + :diff WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':diff', $diff);
            $stmtStok->bindParam(':item_id', $this->item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function delete($item_id, $jumlah) {
        try {
            $this->conn->beginTransaction();

            // Cek apakah stok cukup jika dihapus (menghapus barang masuk = mengurangi stok)
            $queryCekStok = "SELECT stok FROM items WHERE id = :item_id";
            $stmtCek = $this->conn->prepare($queryCekStok);
            $stmtCek->bindParam(':item_id', $item_id);
            $stmtCek->execute();
            $row = $stmtCek->fetch(PDO::FETCH_ASSOC);

            if ($row['stok'] < $jumlah) {
                $this->conn->rollBack();
                return false; // Stok akan negatif jika dihapus
            }

            $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $this->id = htmlspecialchars(strip_tags($this->id));
            $stmt->bindParam(':id', $this->id);
            $stmt->execute();

            // Update Stok
            $queryStok = "UPDATE items SET stok = stok - :jumlah WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':jumlah', $jumlah);
            $stmtStok->bindParam(':item_id', $item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function getTotal() {
        $query = "SELECT SUM(jumlah) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ? $row['total'] : 0;
    }

    public function getRecent($limit = 5) {
        $query = "SELECT inc.*, i.nama_barang 
                  FROM " . $this->table_name . " inc 
                  LEFT JOIN items i ON inc.item_id = i.id 
                  ORDER BY inc.tanggal DESC, inc.id DESC LIMIT " . $limit;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getMonthlyStats() {
        $query = "SELECT DATE_FORMAT(tanggal, '%Y-%m') as month, SUM(jumlah) as total 
                  FROM " . $this->table_name . " 
                  GROUP BY month ORDER BY month DESC LIMIT 6";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
