<?php

class OutgoingItem {
    private $conn;
    private $table_name = "outgoing_items";

    public $id;
    public $item_id;
    public $tanggal;
    public $jumlah;
    public $keterangan;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT outg.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM " . $this->table_name . " outg 
                  LEFT JOIN items i ON outg.item_id = i.id 
                  ORDER BY outg.tanggal DESC, outg.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT outg.*, i.kode_barang, i.nama_barang, i.satuan 
                  FROM " . $this->table_name . " outg 
                  LEFT JOIN items i ON outg.item_id = i.id 
                  WHERE outg.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create() {
        try {
            $this->conn->beginTransaction();

            // Cek Stok
            $queryCekStok = "SELECT stok FROM items WHERE id = :item_id";
            $stmtCek = $this->conn->prepare($queryCekStok);
            $stmtCek->bindParam(':item_id', $this->item_id);
            $stmtCek->execute();
            $row = $stmtCek->fetch(PDO::FETCH_ASSOC);

            if ($row['stok'] < $this->jumlah) {
                $this->conn->rollBack();
                return 'insufficient_stock';
            }

            $query = "INSERT INTO " . $this->table_name . " 
                      (item_id, tanggal, jumlah, keterangan) 
                      VALUES (:item_id, :tanggal, :jumlah, :keterangan)";
            $stmt = $this->conn->prepare($query);

            $this->item_id = htmlspecialchars(strip_tags($this->item_id));
            $this->tanggal = htmlspecialchars(strip_tags($this->tanggal));
            $this->jumlah = htmlspecialchars(strip_tags($this->jumlah));
            $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));

            $stmt->bindParam(':item_id', $this->item_id);
            $stmt->bindParam(':tanggal', $this->tanggal);
            $stmt->bindParam(':jumlah', $this->jumlah);
            $stmt->bindParam(':keterangan', $this->keterangan);

            $stmt->execute();

            // Update Stok
            $queryStok = "UPDATE items SET stok = stok - :jumlah WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':jumlah', $this->jumlah);
            $stmtStok->bindParam(':item_id', $this->item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function update($old_jumlah) {
        try {
            $this->conn->beginTransaction();

            // Cek Stok untuk perubahan
            $diff = $this->jumlah - $old_jumlah; // Jika positif, stok akan berkurang lebih banyak
            
            if ($diff > 0) {
                $queryCekStok = "SELECT stok FROM items WHERE id = :item_id";
                $stmtCek = $this->conn->prepare($queryCekStok);
                $stmtCek->bindParam(':item_id', $this->item_id);
                $stmtCek->execute();
                $row = $stmtCek->fetch(PDO::FETCH_ASSOC);

                if ($row['stok'] < $diff) {
                    $this->conn->rollBack();
                    return 'insufficient_stock';
                }
            }

            $query = "UPDATE " . $this->table_name . " 
                      SET item_id = :item_id, tanggal = :tanggal, 
                          jumlah = :jumlah, keterangan = :keterangan 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);

            $this->item_id = htmlspecialchars(strip_tags($this->item_id));
            $this->tanggal = htmlspecialchars(strip_tags($this->tanggal));
            $this->jumlah = htmlspecialchars(strip_tags($this->jumlah));
            $this->keterangan = htmlspecialchars(strip_tags($this->keterangan));
            $this->id = htmlspecialchars(strip_tags($this->id));

            $stmt->bindParam(':item_id', $this->item_id);
            $stmt->bindParam(':tanggal', $this->tanggal);
            $stmt->bindParam(':jumlah', $this->jumlah);
            $stmt->bindParam(':keterangan', $this->keterangan);
            $stmt->bindParam(':id', $this->id);

            $stmt->execute();

            // Update Stok: Restore old stock then subtract/add new stock
            $queryStok = "UPDATE items SET stok = stok - :diff WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':diff', $diff);
            $stmtStok->bindParam(':item_id', $this->item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function delete($item_id, $jumlah) {
        try {
            $this->conn->beginTransaction();

            $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $this->id = htmlspecialchars(strip_tags($this->id));
            $stmt->bindParam(':id', $this->id);
            $stmt->execute();

            // Update Stok (Menghapus barang keluar = menambah stok)
            $queryStok = "UPDATE items SET stok = stok + :jumlah WHERE id = :item_id";
            $stmtStok = $this->conn->prepare($queryStok);
            $stmtStok->bindParam(':jumlah', $jumlah);
            $stmtStok->bindParam(':item_id', $item_id);
            $stmtStok->execute();

            $this->conn->commit();
            return true;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    public function getTotal() {
        $query = "SELECT SUM(jumlah) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ? $row['total'] : 0;
    }

    public function getRecent($limit = 5) {
        $query = "SELECT outg.*, i.nama_barang 
                  FROM " . $this->table_name . " outg 
                  LEFT JOIN items i ON outg.item_id = i.id 
                  ORDER BY outg.tanggal DESC, outg.id DESC LIMIT " . $limit;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getMonthlyStats() {
        $query = "SELECT DATE_FORMAT(tanggal, '%Y-%m') as month, SUM(jumlah) as total 
                  FROM " . $this->table_name . " 
                  GROUP BY month ORDER BY month DESC LIMIT 6";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
