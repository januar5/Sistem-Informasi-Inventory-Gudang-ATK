<?php

class Item {
    private $conn;
    private $table_name = "items";

    public $id;
    public $kode_barang;
    public $nama_barang;
    public $category_id;
    public $supplier_id;
    public $stok;
    public $satuan;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT i.*, c.nama_kategori, s.nama_supplier 
                  FROM " . $this->table_name . " i 
                  LEFT JOIN categories c ON i.category_id = c.id 
                  LEFT JOIN suppliers s ON i.supplier_id = s.id 
                  ORDER BY i.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT i.*, c.nama_kategori, s.nama_supplier 
                  FROM " . $this->table_name . " i 
                  LEFT JOIN categories c ON i.category_id = c.id 
                  LEFT JOIN suppliers s ON i.supplier_id = s.id 
                  WHERE i.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (kode_barang, nama_barang, category_id, supplier_id, stok, satuan) 
                  VALUES (:kode_barang, :nama_barang, :category_id, :supplier_id, :stok, :satuan)";
        $stmt = $this->conn->prepare($query);

        $this->kode_barang = htmlspecialchars(strip_tags($this->kode_barang));
        $this->nama_barang = htmlspecialchars(strip_tags($this->nama_barang));
        $this->category_id = htmlspecialchars(strip_tags($this->category_id));
        $this->supplier_id = htmlspecialchars(strip_tags($this->supplier_id));
        $this->stok = htmlspecialchars(strip_tags($this->stok));
        $this->satuan = htmlspecialchars(strip_tags($this->satuan));

        $stmt->bindParam(':kode_barang', $this->kode_barang);
        $stmt->bindParam(':nama_barang', $this->nama_barang);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':supplier_id', $this->supplier_id);
        $stmt->bindParam(':stok', $this->stok);
        $stmt->bindParam(':satuan', $this->satuan);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET nama_barang = :nama_barang, category_id = :category_id, 
                      supplier_id = :supplier_id, satuan = :satuan 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->nama_barang = htmlspecialchars(strip_tags($this->nama_barang));
        $this->category_id = htmlspecialchars(strip_tags($this->category_id));
        $this->supplier_id = htmlspecialchars(strip_tags($this->supplier_id));
        $this->satuan = htmlspecialchars(strip_tags($this->satuan));
        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(':nama_barang', $this->nama_barang);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':supplier_id', $this->supplier_id);
        $stmt->bindParam(':satuan', $this->satuan);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':id', $this->id);

        try {
            if ($stmt->execute()) {
                return true;
            }
            return false;
        } catch(PDOException $e) {
            return false;
        }
    }

    public function generateKodeBarang() {
        $query = "SELECT kode_barang FROM " . $this->table_name . " ORDER BY id DESC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $last_kode = $row['kode_barang'];
            $number = (int) substr($last_kode, 3);
            $number++;
            $new_kode = "ATK" . str_pad($number, 3, "0", STR_PAD_LEFT);
        } else {
            $new_kode = "ATK001";
        }
        return $new_kode;
    }

    public function checkKodeExists($kode_barang) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE kode_barang = :kode_barang";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':kode_barang', $kode_barang);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            return true;
        }
        return false;
    }

    public function getLowStock($limit = 10) {
        $query = "SELECT i.*, c.nama_kategori, s.nama_supplier 
                  FROM " . $this->table_name . " i 
                  LEFT JOIN categories c ON i.category_id = c.id 
                  LEFT JOIN suppliers s ON i.supplier_id = s.id 
                  WHERE i.stok <= 5 
                  ORDER BY i.stok ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAvailableStock($limit = 10) {
        $query = "SELECT i.*, c.nama_kategori, s.nama_supplier 
                  FROM " . $this->table_name . " i 
                  LEFT JOIN categories c ON i.category_id = c.id 
                  LEFT JOIN suppliers s ON i.supplier_id = s.id 
                  WHERE i.stok > 10 
                  ORDER BY i.stok ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getWarningStock($limit = 10) {
        $query = "SELECT i.*, c.nama_kategori, s.nama_supplier 
                  FROM " . $this->table_name . " i 
                  LEFT JOIN categories c ON i.category_id = c.id 
                  LEFT JOIN suppliers s ON i.supplier_id = s.id 
                  WHERE i.stok > 5 AND i.stok <= 10 
                  ORDER BY i.stok ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotal() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    public function getTotalStok() {
        $query = "SELECT SUM(stok) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ? $row['total'] : 0;
    }
}
