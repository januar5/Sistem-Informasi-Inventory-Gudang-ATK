<?php

class Supplier {
    private $conn;
    private $table_name = "suppliers";

    public $id;
    public $nama_supplier;
    public $alamat;
    public $no_hp;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " (nama_supplier, alamat, no_hp) VALUES (:nama_supplier, :alamat, :no_hp)";
        $stmt = $this->conn->prepare($query);

        $this->nama_supplier = htmlspecialchars(strip_tags($this->nama_supplier));
        $this->alamat = htmlspecialchars(strip_tags($this->alamat));
        $this->no_hp = htmlspecialchars(strip_tags($this->no_hp));

        $stmt->bindParam(':nama_supplier', $this->nama_supplier);
        $stmt->bindParam(':alamat', $this->alamat);
        $stmt->bindParam(':no_hp', $this->no_hp);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nama_supplier = :nama_supplier, alamat = :alamat, no_hp = :no_hp WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->nama_supplier = htmlspecialchars(strip_tags($this->nama_supplier));
        $this->alamat = htmlspecialchars(strip_tags($this->alamat));
        $this->no_hp = htmlspecialchars(strip_tags($this->no_hp));
        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(':nama_supplier', $this->nama_supplier);
        $stmt->bindParam(':alamat', $this->alamat);
        $stmt->bindParam(':no_hp', $this->no_hp);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':id', $this->id);

        try {
            if ($stmt->execute()) {
                return true;
            }
            return false;
        } catch(PDOException $e) {
            return false;
        }
    }

    public function getTotal() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
}
