<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php 
                if(Session::get('user_role') === 'admin') {
                    require_once __DIR__ . '/../layouts/sidebar_admin.php'; 
                } else {
                    require_once __DIR__ . '/../layouts/sidebar_petugas.php';
                }
            ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Profile & Password</h1>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card shadow border-0">
                        <div class="card-header bg-white py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-person-lines-fill me-2"></i>Update Profile</h6>
                        </div>
                        <div class="card-body">
                            <form action="<?= BASE_URL ?>/profile/update" method="POST">
                                <?= Csrf::csrfField() ?>
                                <div class="mb-3">
                                    <label class="form-label">Nama Lengkap</label>
                                    <input type="text" name="name" class="form-control" value="<?= $user['name'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?= $user['email'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Role</label>
                                    <input type="text" class="form-control bg-light" value="<?= ucfirst($user['role']) ?>" disabled>
                                    <div class="form-text">Role tidak dapat diubah sendiri.</div>
                                </div>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Profile</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 mb-4">
                    <div class="card shadow border-0">
                        <div class="card-header bg-white py-3">
                            <h6 class="m-0 font-weight-bold text-danger"><i class="bi bi-shield-lock-fill me-2"></i>Ubah Password</h6>
                        </div>
                        <div class="card-body">
                            <form action="<?= BASE_URL ?>/profile/password" method="POST">
                                <?= Csrf::csrfField() ?>
                                <div class="mb-3">
                                    <label class="form-label">Password Lama</label>
                                    <input type="password" name="old_password" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password Baru</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Konfirmasi Password Baru</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-danger"><i class="bi bi-key me-1"></i> Update Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
