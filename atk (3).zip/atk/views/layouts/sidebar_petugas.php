<div class="offcanvas-md offcanvas-start bg-dark text-white sidebar shadow" tabindex="-1" id="sidebar" aria-labelledby="sidebarLabel">
    <div class="offcanvas-header border-bottom border-secondary d-md-none">
        <h5 class="offcanvas-title" id="sidebarLabel"><i class="bi bi-box-seam me-2"></i>Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0 pt-3 flex-column">
        <ul class="nav flex-column mb-auto px-2 w-100">
            <li class="nav-item mb-1">
                <a href="<?= BASE_URL ?>/dashboard" class="nav-link text-white <?= $path == 'dashboard' ? 'active bg-primary rounded' : '' ?>">
                    <i class="bi bi-speedometer2 me-2"></i>Dashboard
                </a>
            </li>
            
            <li class="nav-item mt-3 mb-1">
                <small class="text-secondary text-uppercase fw-bold px-3">Transaksi</small>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= BASE_URL ?>/incoming" class="nav-link text-white <?= strpos($path, 'incoming') === 0 ? 'active bg-primary rounded' : '' ?>">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Barang Masuk
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= BASE_URL ?>/outgoing" class="nav-link text-white <?= strpos($path, 'outgoing') === 0 ? 'active bg-primary rounded' : '' ?>">
                    <i class="bi bi-box-arrow-right me-2"></i>Barang Keluar
                </a>
            </li>

            <li class="nav-item mt-3 mb-1">
                <small class="text-secondary text-uppercase fw-bold px-3">Laporan</small>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= BASE_URL ?>/report" class="nav-link text-white <?= strpos($path, 'report') === 0 ? 'active bg-primary rounded' : '' ?>">
                    <i class="bi bi-file-earmark-text me-2"></i>Laporan
                </a>
            </li>

            <li class="nav-item mt-3 mb-1">
                <small class="text-secondary text-uppercase fw-bold px-3">Akun</small>
            </li>
            <li class="nav-item mb-1">
                <a href="<?= BASE_URL ?>/profile" class="nav-link text-white <?= strpos($path, 'profile') === 0 ? 'active bg-primary rounded' : '' ?>">
                    <i class="bi bi-person me-2"></i>Profile & Password
                </a>
            </li>
        </ul>
    </div>
</div>
