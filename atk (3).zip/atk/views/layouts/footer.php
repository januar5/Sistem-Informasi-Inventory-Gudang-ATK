    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.1/dist/sweetalert2.all.min.js"></script>
    
    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom JS -->
    <script src="<?= BASE_URL ?>/assets/js/main.js"></script>

    <?php 
    $flash = Helper::getFlash();
    if ($flash): 
    ?>
    <script>
        Swal.fire({
            icon: '<?= $flash['type'] ?>',
            title: '<?= $flash['type'] === 'success' ? 'Berhasil!' : 'Oops...' ?>',
            text: '<?= $flash['message'] ?>',
            timer: 3000,
            showConfirmButton: false
        });
    </script>
    <?php endif; ?>

</body>
</html>
