<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php 
                if(Session::get('user_role') === 'admin') {
                    require_once __DIR__ . '/../layouts/sidebar_admin.php'; 
                } else {
                    require_once __DIR__ . '/../layouts/sidebar_petugas.php';
                }
            ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Edit Transaksi Barang Keluar</h1>
                <a href="<?= BASE_URL ?>/outgoing" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <form action="<?= BASE_URL ?>/outgoing/update/<?= $outgoing['id'] ?>" method="POST">
                        <?= Csrf::csrfField() ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Tanggal Transaksi <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d', strtotime($outgoing['tanggal'])) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Barang <span class="text-danger">*</span></label>
                                <input type="text" class="form-control bg-light" value="[<?= $outgoing['kode_barang'] ?>] <?= $outgoing['nama_barang'] ?>" disabled>
                                <div class="form-text text-danger">Barang tidak dapat diubah setelah transaksi dibuat. Hapus transaksi jika salah barang.</div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Jumlah Keluar <span class="text-danger">*</span></label>
                                <input type="number" name="jumlah" class="form-control" min="1" value="<?= $outgoing['jumlah'] ?>" required>
                                <div class="form-text text-danger">Ubah jumlah ini untuk menyesuaikan pengeluaran. (Saat ini: <?= $outgoing['jumlah'] ?> <?= $outgoing['satuan'] ?>)</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Keterangan / Tujuan Penggunaan <span class="text-danger">*</span></label>
                                <textarea name="keterangan" class="form-control" rows="2" required><?= $outgoing['keterangan'] ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Update Transaksi</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
