<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid vh-100 d-flex justify-content-center align-items-center bg-primary" style="background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);">
    <div class="card shadow-lg border-0 rounded-4" style="width: 100%; max-width: 450px;">
        <div class="card-body p-5">
            <div class="text-center mb-4">
                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex p-3 mb-3">
                    <i class="bi bi-box-seam fs-1"></i>
                </div>
                <h3 class="fw-bold">Login Sistem</h3>
                <p class="text-muted">Inventory Gudang ATK</p>
            </div>

            <form action="<?= BASE_URL ?>/login" method="POST">
                <?= Csrf::csrfField() ?>
                
                <div class="mb-3">
                    <label class="form-label text-muted fw-semibold">Email Address</label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control border-start-0 bg-light" placeholder="Masukkan email" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label text-muted fw-semibold">Password</label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control border-start-0 bg-light" placeholder="Masukkan password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill fw-bold shadow-sm">
                    Login
                </button>
            </form>
            
            <div class="text-center mt-4 text-muted small">
                &copy; <?= date('Y') ?> Inventory ATK. All rights reserved.
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
