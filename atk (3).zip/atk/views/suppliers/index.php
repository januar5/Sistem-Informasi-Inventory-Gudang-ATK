<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php require_once __DIR__ . '/../layouts/sidebar_admin.php'; ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Manajemen Supplier</h1>
                <a href="<?= BASE_URL ?>/supplier/create" class="btn btn-primary shadow-sm"><i class="bi bi-plus-circle me-2"></i>Tambah Supplier</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Supplier</th>
                                    <th>Alamat</th>
                                    <th>No HP</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=1; foreach($suppliers as $sup): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $sup['nama_supplier'] ?></td>
                                    <td><?= $sup['alamat'] ?></td>
                                    <td><?= $sup['no_hp'] ?></td>
                                    <td>
                                        <a href="<?= BASE_URL ?>/supplier/edit/<?= $sup['id'] ?>" class="btn btn-sm btn-warning" title="Edit"><i class="bi bi-pencil"></i></a>
                                        <form action="<?= BASE_URL ?>/supplier/delete/<?= $sup['id'] ?>" method="POST" class="d-inline form-delete">
                                            <?= Csrf::csrfField() ?>
                                            <button type="submit" class="btn btn-sm btn-danger btn-delete" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#dataTable').DataTable();
    
    $('.btn-delete').click(function(e) {
        e.preventDefault();
        let form = $(this).closest('form');
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data supplier akan dihapus!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
