<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php require_once __DIR__ . '/../layouts/sidebar_admin.php'; ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Detail Barang</h1>
                <a href="<?= BASE_URL ?>/item" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-header bg-white py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-info-circle me-2"></i>Informasi Barang: <?= $item['kode_barang'] ?></h6>
                    <a href="<?= BASE_URL ?>/item/edit/<?= $item['id'] ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil me-1"></i> Edit</a>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th width="30%">Kode Barang</th>
                            <td><span class="badge bg-secondary fs-6"><?= $item['kode_barang'] ?></span></td>
                        </tr>
                        <tr>
                            <th>Nama Barang</th>
                            <td class="fw-bold"><?= $item['nama_barang'] ?></td>
                        </tr>
                        <tr>
                            <th>Kategori</th>
                            <td><?= $item['nama_kategori'] ?></td>
                        </tr>
                        <tr>
                            <th>Supplier</th>
                            <td><?= $item['nama_supplier'] ?></td>
                        </tr>
                        <tr>
                            <th>Stok Tersedia</th>
                            <td>
                                <?php if($item['stok'] < 10): ?>
                                    <span class="badge bg-danger fs-6"><?= $item['stok'] ?> <?= $item['satuan'] ?></span>
                                    <small class="text-danger ms-2"><i class="bi bi-exclamation-triangle"></i> Stok Rendah!</small>
                                <?php else: ?>
                                    <span class="badge bg-success fs-6"><?= $item['stok'] ?> <?= $item['satuan'] ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Tanggal Ditambahkan</th>
                            <td><?= date('d F Y H:i', strtotime($item['created_at'])) ?></td>
                        </tr>
                        <tr>
                            <th>Update Terakhir</th>
                            <td><?= date('d F Y H:i', strtotime($item['updated_at'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
