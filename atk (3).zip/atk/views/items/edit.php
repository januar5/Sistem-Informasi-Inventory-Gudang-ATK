<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php require_once __DIR__ . '/../layouts/sidebar_admin.php'; ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Edit Barang</h1>
                <a href="<?= BASE_URL ?>/item" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <form action="<?= BASE_URL ?>/item/update/<?= $item['id'] ?>" method="POST">
                        <?= Csrf::csrfField() ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Kode Barang</label>
                                <input type="text" class="form-control bg-light" value="<?= $item['kode_barang'] ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Nama Barang <span class="text-danger">*</span></label>
                                <input type="text" name="nama_barang" class="form-control" value="<?= $item['nama_barang'] ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Kategori <span class="text-danger">*</span></label>
                                <select name="category_id" class="form-select" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php foreach($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $item['category_id'] == $cat['id'] ? 'selected' : '' ?>><?= $cat['nama_kategori'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Supplier <span class="text-danger">*</span></label>
                                <select name="supplier_id" class="form-select" required>
                                    <option value="">Pilih Supplier</option>
                                    <?php foreach($suppliers as $sup): ?>
                                    <option value="<?= $sup['id'] ?>" <?= $item['supplier_id'] == $sup['id'] ? 'selected' : '' ?>><?= $sup['nama_supplier'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label">Stok <span class="text-muted">(Tidak dapat diubah manual)</span></label>
                                <input type="number" class="form-control bg-light" value="<?= $item['stok'] ?>" disabled>
                                <div class="form-text">Stok otomatis diupdate dari transaksi masuk/keluar.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Satuan <span class="text-danger">*</span></label>
                                <input type="text" name="satuan" class="form-control" value="<?= $item['satuan'] ?>" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Update Data</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
