<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php 
                if(Session::get('user_role') === 'admin') {
                    require_once __DIR__ . '/../layouts/sidebar_admin.php'; 
                } else {
                    require_once __DIR__ . '/../layouts/sidebar_petugas.php';
                }
            ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Cetak Laporan</h1>
            </div>

            <div class="row">
                <!-- Laporan Barang -->
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="card border-0 shadow h-100">
                        <div class="card-body text-center d-flex flex-column justify-content-center py-4">
                            <i class="bi bi-box fs-1 text-primary mb-3"></i>
                            <h5 class="card-title fw-bold">Laporan Barang</h5>
                            <p class="card-text text-muted small mb-4">Cetak seluruh daftar master barang beserta kategorinya.</p>
                            <div class="mt-auto">
                                <a href="<?= BASE_URL ?>/report/print_barang" target="_blank" class="btn btn-outline-primary w-100 mb-2"><i class="bi bi-printer me-1"></i> Print / Preview</a>
                                <a href="<?= BASE_URL ?>/report/print_barang?export=pdf" class="btn btn-danger w-100 mb-2"><i class="bi bi-file-earmark-pdf me-1"></i> Export PDF</a>
                                <a href="<?= BASE_URL ?>/report/print_barang?export=excel" class="btn btn-success w-100"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Laporan Stok -->
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="card border-0 shadow h-100">
                        <div class="card-body text-center d-flex flex-column justify-content-center py-4">
                            <i class="bi bi-stack fs-1 text-secondary mb-3"></i>
                            <h5 class="card-title fw-bold">Laporan Stok</h5>
                            <p class="card-text text-muted small mb-4">Cetak laporan jumlah stok terkini seluruh barang.</p>
                            <div class="mt-auto">
                                <a href="<?= BASE_URL ?>/report/print_stok" target="_blank" class="btn btn-outline-secondary w-100 mb-2"><i class="bi bi-printer me-1"></i> Print / Preview</a>
                                <a href="<?= BASE_URL ?>/report/print_stok?export=pdf" class="btn btn-danger w-100 mb-2"><i class="bi bi-file-earmark-pdf me-1"></i> Export PDF</a>
                                <a href="<?= BASE_URL ?>/report/print_stok?export=excel" class="btn btn-success w-100"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Laporan Barang Masuk -->
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="card border-0 shadow h-100">
                        <div class="card-body py-4">
                            <div class="text-center mb-3">
                                <i class="bi bi-box-arrow-in-right fs-1 text-success"></i>
                                <h5 class="card-title fw-bold mt-2">Barang Masuk</h5>
                            </div>
                            <form action="<?= BASE_URL ?>/report/print_masuk" method="GET" target="_blank">
                                <div class="mb-2">
                                    <label class="form-label small">Dari Tanggal</label>
                                    <input type="date" name="start_date" class="form-control form-control-sm">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small">Sampai Tanggal</label>
                                    <input type="date" name="end_date" class="form-control form-control-sm">
                                </div>
                                <div class="d-grid gap-2 mt-auto">
                                    <button type="submit" class="btn btn-outline-success btn-sm"><i class="bi bi-printer me-1"></i> Print / Preview</button>
                                    <button type="submit" name="export" value="pdf" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf me-1"></i> Export PDF</button>
                                    <button type="submit" name="export" value="excel" class="btn btn-success btn-sm"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Laporan Barang Keluar -->
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="card border-0 shadow h-100">
                        <div class="card-body py-4">
                            <div class="text-center mb-3">
                                <i class="bi bi-box-arrow-right fs-1 text-warning"></i>
                                <h5 class="card-title fw-bold mt-2">Barang Keluar</h5>
                            </div>
                            <form action="<?= BASE_URL ?>/report/print_keluar" method="GET" target="_blank">
                                <div class="mb-2">
                                    <label class="form-label small">Dari Tanggal</label>
                                    <input type="date" name="start_date" class="form-control form-control-sm">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small">Sampai Tanggal</label>
                                    <input type="date" name="end_date" class="form-control form-control-sm">
                                </div>
                                <div class="d-grid gap-2 mt-auto">
                                    <button type="submit" class="btn btn-outline-warning btn-sm"><i class="bi bi-printer me-1"></i> Print / Preview</button>
                                    <button type="submit" name="export" value="pdf" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf me-1"></i> Export PDF</button>
                                    <button type="submit" name="export" value="excel" class="btn btn-success btn-sm"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
