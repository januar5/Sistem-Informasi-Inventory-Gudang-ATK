<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php 
                if(Session::get('user_role') === 'admin') {
                    require_once __DIR__ . '/../layouts/sidebar_admin.php'; 
                } else {
                    require_once __DIR__ . '/../layouts/sidebar_petugas.php';
                }
            ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Transaksi Barang Masuk</h1>
                <a href="<?= BASE_URL ?>/incoming" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <form action="<?= BASE_URL ?>/incoming/store" method="POST">
                        <?= Csrf::csrfField() ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Tanggal Transaksi <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Pilih Barang <span class="text-danger">*</span></label>
                                <select name="item_id" class="form-select" required>
                                    <option value="">-- Pilih Barang --</option>
                                    <?php foreach($items as $item): ?>
                                    <option value="<?= $item['id'] ?>">[<?= $item['kode_barang'] ?>] <?= $item['nama_barang'] ?> - Stok: <?= $item['stok'] ?> <?= $item['satuan'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Jumlah Masuk <span class="text-danger">*</span></label>
                                <input type="number" name="jumlah" class="form-control" min="1" required>
                                <div class="form-text">Stok akan bertambah sesuai jumlah ini.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Keterangan</label>
                                <textarea name="keterangan" class="form-control" rows="2" placeholder="Contoh: Pembelian rutin, Retur dari cabang, dll"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Transaksi</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
