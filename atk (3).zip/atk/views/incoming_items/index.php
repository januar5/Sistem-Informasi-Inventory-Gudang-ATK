<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php 
                if(Session::get('user_role') === 'admin') {
                    require_once __DIR__ . '/../layouts/sidebar_admin.php'; 
                } else {
                    require_once __DIR__ . '/../layouts/sidebar_petugas.php';
                }
            ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Barang Masuk</h1>
                <a href="<?= BASE_URL ?>/incoming/create" class="btn btn-primary shadow-sm"><i class="bi bi-plus-circle me-2"></i>Tambah Transaksi</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <?php if(empty($incoming_items)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted mb-3 d-block"></i>
                            <h5 class="text-muted">Belum ada transaksi barang masuk</h5>
                            <p class="text-muted small mb-0">Klik tombol Tambah Transaksi untuk mencatat barang masuk.</p>
                        </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Tanggal</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah Masuk</th>
                                    <th>Keterangan</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=1; foreach($incoming_items as $inc): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= date('d/m/Y', strtotime($inc['tanggal'])) ?></td>
                                    <td><span class="badge bg-secondary"><?= $inc['kode_barang'] ?></span></td>
                                    <td><?= $inc['nama_barang'] ?></td>
                                    <td><span class="text-success fw-bold">+<?= $inc['jumlah'] ?></span> <?= $inc['satuan'] ?></td>
                                    <td><?= $inc['keterangan'] ?></td>
                                    
                                    <td>
                                        <a href="<?= BASE_URL ?>/incoming/edit/<?= $inc['id'] ?>" class="btn btn-sm btn-warning" title="Edit"><i class="bi bi-pencil"></i></a>
                                        <form action="<?= BASE_URL ?>/incoming/delete/<?= $inc['id'] ?>" method="POST" class="d-inline form-delete">
                                            <?= Csrf::csrfField() ?>
                                            <button type="submit" class="btn btn-sm btn-danger btn-delete" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#dataTable').DataTable();
    
    $('.btn-delete').click(function(e) {
        e.preventDefault();
        let form = $(this).closest('form');
        Swal.fire({
            title: 'Hapus Transaksi?',
            text: "Stok barang akan dikurangi sesuai jumlah transaksi ini karena data dibatalkan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
