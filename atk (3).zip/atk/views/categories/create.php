<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php require_once __DIR__ . '/../layouts/sidebar_admin.php'; ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Tambah Kategori</h1>
                <a href="<?= BASE_URL ?>/category" class="btn btn-secondary shadow-sm"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <div class="card shadow mb-4 border-0">
                <div class="card-body">
                    <form action="<?= BASE_URL ?>/category/store" method="POST">
                        <?= Csrf::csrfField() ?>
                        <div class="mb-4">
                            <label class="form-label">Nama Kategori <span class="text-danger">*</span></label>
                            <input type="text" name="nama_kategori" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
