<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block collapse p-0">
            <?php require_once __DIR__ . '/../layouts/sidebar_petugas.php'; ?>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5 pt-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
                <h1 class="h2 fw-bold text-gray-800">Dashboard Petugas</h1>
            </div>

            <!-- Stats Row 1 -->
            <div class="row mb-4 g-3">
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-primary border-4 shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Barang</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_barang']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-box fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-success border-4 shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Kategori</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_kategori']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-tags fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-info border-4 shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Supplier</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_supplier']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-truck fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Row 2 -->
            <div class="row mb-4 g-3">
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-warning border-4 shadow h-100 py-2 bg-gradient">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Barang Masuk</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_masuk']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-box-arrow-in-right fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-danger border-4 shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Barang Keluar</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_keluar']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-box-arrow-right fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card border-0 border-start border-secondary border-4 shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Total Stok</div>
                                    <div class="h3 mb-0 font-weight-bold text-gray-800"><?= number_format($data['total_stok']) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-stack fs-1 text-gray-300 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row mb-4">
                <div class="col-xl-8 col-lg-7">
                    <div class="card shadow mb-4 border-0">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between bg-white border-bottom">
                            <h6 class="m-0 font-weight-bold text-primary">Grafik Transaksi 6 Bulan Terakhir</h6>
                        </div>
                        <div class="card-body">
                            <div class="chart-area" style="height: 300px;">
                                <canvas id="transactionChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Alerts Column -->
                <div class="col-xl-4 col-lg-5">
                    
                    <!-- Stok Tidak Tersedia (< 5) -->
                    <div class="card shadow mb-4 border-0">
                        <div class="card-header py-3 bg-white border-bottom">
                            <h6 class="m-0 font-weight-bold text-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Stok Tidak Tersedia (<= 5)</h6>
                        </div>
                        <div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
                            <ul class="list-group list-group-flush">
                                <?php if(empty($data['low_stock'])): ?>
                                    <li class="list-group-item text-center text-muted py-3">Tidak ada barang.</li>
                                <?php else: ?>
                                    <?php foreach($data['low_stock'] as $item): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <div class="fw-bold"><?= $item['nama_barang'] ?></div>
                                            <small class="text-muted"><?= $item['kode_barang'] ?></small>
                                        </div>
                                        <span class="badge bg-danger rounded-pill"><?= $item['stok'] ?> <?= $item['satuan'] ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- Stok Warning (= 10) -->
                    <div class="card shadow mb-4 border-0">
                        <div class="card-header py-3 bg-white border-bottom">
                            <h6 class="m-0 font-weight-bold text-warning"><i class="bi bi-exclamation-circle-fill me-2"></i>Stok Warning (<= 10)</h6>
                        </div>
                        <div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
                            <ul class="list-group list-group-flush">
                                <?php if(empty($data['warning_stock'])): ?>
                                    <li class="list-group-item text-center text-muted py-3">Tidak ada barang.</li>
                                <?php else: ?>
                                    <?php foreach($data['warning_stock'] as $item): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <div class="fw-bold"><?= $item['nama_barang'] ?></div>
                                            <small class="text-muted"><?= $item['kode_barang'] ?></small>
                                        </div>
                                        <span class="badge bg-warning text-dark rounded-pill"><?= $item['stok'] ?> <?= $item['satuan'] ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- Stok Tersedia (> 15) -->
                    <div class="card shadow mb-4 border-0">
                        <div class="card-header py-3 bg-white border-bottom">
                            <h6 class="m-0 font-weight-bold text-success"><i class="bi bi-check-circle-fill me-2"></i>Stok Tersedia (> 10)</h6>
                        </div>
                        <div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
                            <ul class="list-group list-group-flush">
                                <?php if(empty($data['available_stock'])): ?>
                                    <li class="list-group-item text-center text-muted py-3">Tidak ada barang.</li>
                                <?php else: ?>
                                    <?php foreach($data['available_stock'] as $item): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <div class="fw-bold"><?= $item['nama_barang'] ?></div>
                                            <small class="text-muted"><?= $item['kode_barang'] ?></small>
                                        </div>
                                        <span class="badge bg-success rounded-pill"><?= $item['stok'] ?> <?= $item['satuan'] ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Status Persediaan Barang Row -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card shadow mb-4 border-0">
                        <div class="card-header py-3 bg-white border-bottom">
                            <h6 class="m-0 font-weight-bold text-primary">Status Persediaan Barang</h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light sticky-top">
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Barang</th>
                                            <th>Stok</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(empty($data['all_items'])): ?>
                                        <tr><td colspan="4" class="text-center text-muted">Belum ada data</td></tr>
                                        <?php else: ?>
                                            <?php foreach($data['all_items'] as $item): 
                                                $status = '';
                                                $badgeClass = '';
                                                if ($item['stok'] > 10) {
                                                    $status = 'Tersedia';
                                                    $badgeClass = 'bg-success';
                                                } elseif ($item['stok'] <= 5) {
                                                    $status = 'Tidak Tersedia';
                                                    $badgeClass = 'bg-danger';
                                                } else {
                                                    $status = 'Warning';
                                                    $badgeClass = 'bg-warning text-dark';
                                                }
                                            ?>
                                            <tr>
                                                <td><?= $item['kode_barang'] ?></td>
                                                <td><?= $item['nama_barang'] ?></td>
                                                <td><?= $item['stok'] ?> <?= $item['satuan'] ?></td>
                                                <td><span class="badge <?= $badgeClass ?>"><?= $status ?></span></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<?php
// Prepare data for chart (same as admin)
$months = [];
$incoming_data = [];
$outgoing_data = [];

$monthMap = [];
foreach($data['chart_incoming'] as $c) {
    $monthMap[$c['month']]['in'] = $c['total'];
}
foreach($data['chart_outgoing'] as $c) {
    $monthMap[$c['month']]['out'] = $c['total'];
}

ksort($monthMap);

foreach($monthMap as $month => $val) {
    $months[] = date('M Y', strtotime($month . '-01'));
    $incoming_data[] = isset($val['in']) ? $val['in'] : 0;
    $outgoing_data[] = isset($val['out']) ? $val['out'] : 0;
}
?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById('transactionChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar', // Petugas gets a bar chart for variety
        data: {
            labels: <?= json_encode($months) ?>,
            datasets: [
                {
                    label: 'Barang Masuk',
                    data: <?= json_encode($incoming_data) ?>,
                    backgroundColor: 'rgba(78, 115, 223, 0.8)',
                },
                {
                    label: 'Barang Keluar',
                    data: <?= json_encode($outgoing_data) ?>,
                    backgroundColor: 'rgba(231, 74, 59, 0.8)',
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
